# newapp.R
library(shiny)
library(ggplot2)

# Load once (much faster than reading on every query
prefix <- "/Users/jieun/Work/Git_test/Seurat/Spatial/Brain/"
Load <- function(x) readRDS(paste0(prefix,x))
expr <- Load("brain_expr.RDS")
dt0  <- Load("brain_coords.RDS")

new_colors <- c("#FF0000", "#00FF00", "#0000FF", "#FFFF00", "#FF00FF",
                "#00FFFF", "#FF8000", "#008000", "#8000FF", "#800080", "#FF0060",
                "#80AF00", "#0090FF", "#FFAF00", "#808080")

Plot <- function(gene, expr, dt0) {
  if (!(gene %in% colnames(expr))) return(NULL)

  dt <- dt0
  dt[[gene]] <- expr[, gene]

  ggplot(dt, aes(x = y, y = -x)) +
    geom_point(aes(color = factor(cluster)), size = 4.2) +
    scale_color_manual(values = new_colors) +
    geom_point(
      aes(fill = .data[[gene]]),
      shape = 21, size = 2.8, stroke = 0
    ) +
    scale_fill_gradient(low = "black", high = "white", name = gene)
}

ui <- fluidPage(
  titlePanel("Spatial plot by gene"),
  sidebarLayout(
    sidebarPanel(
      textInput("gene", "Gene", value = "Sst"),
      actionButton("go", "Plot"),
      helpText("Enter a gene name exactly as in expr colnames()."),
      br(),
      downloadButton("pdf", "Download PDF")
    ),
    mainPanel(
      plotOutput("p", height = "800px"),
      verbatimTextOutput("msg")
    )
  )
)

server <- function(input, output, session) {
  gene_r <- eventReactive(input$go, {
    g <- trimws(input$gene)
    if (nzchar(g)) g else NULL
  }, ignoreInit = TRUE)

  plot_r <- reactive({
    g <- gene_r()
    if (is.null(g)) return(NULL)
    Plot(g, expr, dt0)
  })

  output$msg <- renderText({
    g <- gene_r()
    if (is.null(g)) return("Enter a gene and click Plot.")
    if (!(g %in% colnames(expr))) return(paste0("'", g, "' not in the data."))
    ""
  })

  output$p <- renderPlot({
    p <- plot_r()
    validate(need(!is.null(p), "No plot to show (gene not found?)."))
    p
  })

  output$pdf <- downloadHandler(
    filename = function() paste0(gene_r() %||% "plot", "_t_plot.pdf"),
    content = function(file) {
      g <- gene_r()
      if (is.null(g) || !(g %in% colnames(expr))) stop("Gene not found.")
      ggsave(file, Plot(g, expr, dt0), width = 9, height = 9, units = "in")
    }
  )
}

# A tiny helper (optional) so filename line works even without your `%||%`
`%||%` <- function(x, y) if (!is.null(x)) x else y

shinyApp(ui, server)
