Description:
  This is an Rshiny application to explore together
  - classification of voxels into 15 meaningful clusters
  - gene expression in voxels
  For each voxel, we use two concentric circles:
  - larger to color-code the cluster
  - smaller to code expression in log scale with black-to-white gradient
  For example, Plp1 gene has highest expression range in cluster 12, lower expression in (mostly) surrounding cluster 1 and yet lower elsewhere, together with co-expressed gene it gives biological insights.

Installation:
  - download and decompress directory shiny_two_layer/ to selected path X
  - in X/shiny_two_layer edit prefix <- ... to X

Running:
  - in directory X
Rscript -e "shiny::runApp('shiny_two_layer', launch.browser=TRUE)"
  - when done, close with Ctrl-C

Using:
  - type a gene name in "Gene" panel, click on "Plot" button
  - click on Download to save the plot, downloaded plot get larger circles which makes it less nice but more readable for expression.
